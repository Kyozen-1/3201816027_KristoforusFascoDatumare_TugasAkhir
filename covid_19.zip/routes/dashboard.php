<?php
Route::get('/admin/dashboard', 'DashboardController@index')->name('dashboard');