<?php

Breadcrumbs::for('dashboard', function($trail){
    $trail->push('Dashboard', route('dashboard'));
});